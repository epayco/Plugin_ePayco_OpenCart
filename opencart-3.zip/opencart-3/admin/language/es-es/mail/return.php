<?php
// Text
$_['text_subject'] = '% s - Devoluci&oacute;n actualizaci&oacute;n% s';
$_['text_return_id'] = 'Devoluci&oacute;n ID:';
$_['text_date_added'] = 'fecha de Devoluci&oacute;n:';
$_['text_return_status'] = 'Su devoluci&oacute;n ha sido actualizado para el siguiente estado:';
$_['text_comment'] = 'Los comentarios de su declaraci&oacute;n son:';
$_['text_footer'] = 'Por favor, responda a este correo electr&oacute;nico si usted tiene alguna pregunta.';