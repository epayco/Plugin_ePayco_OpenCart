<?php
// Text
$_['text_approve_subject'] = '% s - Su cuenta ha sido activada!';
$_['text_approve_welcome'] = 'Bienvenidos y gracias por registrarse en% s!';
$_['text_approve_login'] = 'Su cuenta ha sido creada y usted puede iniciar sesi&oacute;n utilizando su direcci&oacute;n de correo electr&oacute;nico y contrase&ntilde;a, visite nuestro sitio web o la siguiente URL:';
$_['text_approve_services'] = 'Al iniciar la sesi&oacute;n, usted podr&aacute; acceder a otros servicios, como la revisi&oacute;n de las &oacute;rdenes anteriores, las facturas de impresi&oacute;n y edici&oacute;n de la informaci&oacute;n de su cuenta.';
$_['text_approve_thanks'] = 'Gracias,';
$_['text_transaction_subject'] = '% s - Cuenta de Cr&eacute;dito';
$_['text_transaction_received'] = 'Usted ha recibido cr&eacute;dito% s!';
$_['text_transaction_total'] = 'Su importe total del cr&eacute;dito es ahora% s.' . "\ n \ n". "Su cr&eacute;dito cuenta se deducir&aacute; autom&aacute;ticamente de su pr&oacute;xima compra. ';
$_['text_reward_subject'] = '% s - Puntos de recompensa';
$_['text_reward_received'] = 'Usted ha recibido% s Puntos de recompensa!';
$_['text_reward_total'] = 'El n�mero total de puntos de recompensa es ahora% s.';