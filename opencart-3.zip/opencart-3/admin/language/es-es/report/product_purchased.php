<?php
// Heading
$_['heading_title']     = 'Informe de Productos Vendidos';

// Text
$_['text_list']         = 'Lista de Productos Vendidos';
$_['text_all_status']   = 'Todos los Estados';

// Column
$_['column_date_start'] = 'Fecha Inicio';
$_['column_date_end']   = 'Fecha Fin';
$_['column_name']       = 'Producto';
$_['column_model']      = 'Modelo';
$_['column_quantity']   = 'Cantidad';
$_['column_total']      = 'Total';

// Entry
$_['entry_date_start']  = 'Fecha Inicio';
$_['entry_date_end']    = 'Fecha Fin';
$_['entry_status']      = 'Estado del Pedido';