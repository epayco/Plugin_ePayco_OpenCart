<?php
// Heading
$_['heading_title']    = 'Informe de Productos Visualizados';

// Text
$_['text_list']        = 'Lista de Productos Visualizados';
$_['text_success']     = 'Genial: Ha reseteado el informe de productos visualizados!';

// Column
$_['column_name']      = 'Nombre del Producto';
$_['column_model']     = 'Modelo';
$_['column_viewed']    = 'Visualizaciones';
$_['column_percent']   = 'Porcentaje';

// Error
$_['error_permission'] = 'Antenci&oacute;n: Usted no tiene permisos para resetear el informe de productos visualizados!';