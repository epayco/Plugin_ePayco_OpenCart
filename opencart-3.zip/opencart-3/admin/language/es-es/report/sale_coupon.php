<?php
// Heading
$_['heading_title']    = 'Informe de Cupones';

// Text
$_['text_list']        = 'Lista de Cupones';

// Column
$_['column_name']      = 'Nombre del Cupon';
$_['column_code']      = 'C&oacute;digo';
$_['column_orders']    = 'Pedidos';
$_['column_total']     = 'Total';
$_['column_action']    = 'Acci&oacute;n';

// Entry
$_['entry_date_start'] = 'Fecha Inicio';
$_['entry_date_end']   = 'Fecha Fin';