<?php
// Heading
$_['heading_title']    = 'Informe de Marketing';

// Text
$_['text_list']         = 'Lista de Marketing';
$_['text_all_status']   = 'Todos los Estados';

// Column
$_['column_campaign']  = 'Nombre de la Campa&ntilde;a';
$_['column_code']      = 'C&oacute;digo';
$_['column_clicks']    = 'Clicks';
$_['column_orders']    = 'No. Pedidos';
$_['column_total']     = 'Total';

// Entry
$_['entry_date_start'] = 'Fecha Inicio';
$_['entry_date_end']   = 'Fecha Fin';
$_['entry_status']     = 'Estados de Pedidos';