<?php
// Heading
$_['heading_title']     = 'Informe de Comisiones de Afiliados';

// Text
$_['text_list']         = 'Lista de Comisiones de Afiliados';

// Column
$_['column_affiliate']  = 'Nombre de Afiliado';
$_['column_email']      = 'E-Mail';
$_['column_status']     = 'Estado';
$_['column_commission'] = 'Comisiones';
$_['column_orders']     = 'No. pedidos';
$_['column_total']      = 'Total';
$_['column_action']     = 'Acci&oacute;n';

// Entry
$_['entry_date_start']  = 'Fecha Inicio';
$_['entry_date_end']    = 'Fecha Fin';