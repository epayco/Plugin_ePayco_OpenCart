<?php
// Heading
$_['heading_title']         = 'Informe de Cr&eacute;dito de Clientes';

// Column
$_['text_list']             = 'Lista de Cr&eacute;ditos';
$_['column_customer']       = 'Nombre del cliente';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Grupo de Clientes';
$_['column_status']         = 'Estado';
$_['column_total']          = 'Total';
$_['column_action']         = 'Acci&oacute;n';

// Entry
$_['entry_date_start']      = 'Fecha Inicio';
$_['entry_date_end']        = 'Fecha Fin';