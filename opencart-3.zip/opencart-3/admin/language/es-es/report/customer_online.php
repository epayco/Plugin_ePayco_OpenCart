<?php
// Heading
$_['heading_title']     = 'Informe de Clientes Online';

// Text
$_['text_list']         = 'Lista de Clientes Online';
$_['text_guest']        = 'Invitados';

// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Clientes';
$_['column_url']        = 'Su &uacute;ltima p&aacute;gina Visitada';
$_['column_referer']    = 'Referenciante';
$_['column_date_added'] = 'Click Final';
$_['column_action']     = 'Acci&oacute;n';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = 'Cliente';