<?php
// Heading
$_['heading_title']         = 'Informe de Puntos de Recompensa del Cliente';

// Text
$_['text_list']             = 'Lista de Clientes con Puntos de Recompens';

// Column
$_['column_customer']       = 'Nombre del Cliente';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Grupo de Clientes';
$_['column_status']         = 'Estado';
$_['column_points']         = 'Puntos de Recompensa';
$_['column_orders']         = 'No. Pedidos';
$_['column_total']          = 'Total';
$_['column_action']         = 'Acci&oacute;n';

// Entry
$_['entry_date_start']      = 'Fecha Inicio';
$_['entry_date_end']        = 'Fecha Fin';