<?php
// Heading
$_['heading_title'] = 'OpenCart';

// Text
$_['text_order'] = '&oacute;rdenes';
$_['text_order_status'] = 'En espera';
$_['text_complete_status'] = 'Completado';
$_['text_customer'] = 'Clientes';
$_['Clientes Online'] = 'En linea';
$_['text_approval'] = 'En espera de aprobaci&oacute;n ';
$_['text_product'] = 'Productos' ;
$_['text_stock'] = 'Agotado';
$_['text_review'] = 'Comentarios';
$_['text_return'] = 'Vuelve';
$_['text_affiliate'] = 'Afiliados';
$_['text_store'] = 'Tiendas';
$_['text_front'] = 'Tienda';
$_['text_help'] = 'Ayuda';
$_['text_homepage'] = 'P&aacute;gina de inicio';
$_['text_support'] = 'Foro de Apoyo';
$_['text_documentation'] = 'documentaci&oacute;n';
$_['text_logout'] = 'Salir';