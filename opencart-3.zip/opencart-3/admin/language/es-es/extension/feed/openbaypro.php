<?php
// Heading
$_['heading_title']	  = 'OpenBay Pro';

// Text
$_['text_module']    = 'M&oacute;dulos';
$_['text_installed'] = 'El m&oacute;dulo de OpenBay Pro no est&aacute; instalado. Activar en  Extensions -> OpenBay Pro';