<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_feed']        = 'Feeds';
$_['text_success']     = 'Genial: Usted ha modificado el feed de Google Sitemap!';
$_['text_edit']        = 'Editar Google Sitemap';

// Entry
$_['entry_status']     = 'Estado';
$_['entry_data_feed']  = 'Url de Feed de datos';

// Error
$_['error_permission'] = 'Atenci&oacute;n: Usted no tiene permiso para modificar el feed de Google Sitemap!';