<?php
// Heading
$_['heading_title']    = 'Afiliados';

$_['text_module']      = 'M&oacute;dulo';
$_['text_success']     = 'Genial: Ha modificado el m&oacute; de afiliados!';
$_['text_edit']        = 'Editar M&oacute;dulo';

// Entry
$_['entry_status']     = 'Estado';

// Error
$_['error_permission'] = 'Atenci&oacute;n: No tiene permiso para modificar el m&ocute;dulo de afiliados!';