<?php
// Heading
$_['heading_title']    = 'Categor&iacute;a';

// Text
$_['text_module']      = 'M&oacute;dulos';
$_['text_success']     = 'Genial: Usted ha modificado el m&oacute;dulo de las categor&iacute;as!';
$_['text_edit']        = 'Editar M&oacute;dulo';

// Entry
$_['entry_status']     = 'Estado';

// Error
$_['error_permission'] = 'Atenci&oacute;n: No tiene permisos para modificar el m&oacute;dulo de categor&iacute;as!';