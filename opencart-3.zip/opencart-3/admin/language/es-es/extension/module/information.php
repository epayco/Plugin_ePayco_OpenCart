<?php
// Heading
$_['heading_title']    = 'Informaci&oacute;n';

// Text
$_['text_module']      = 'M&oacute;dulos';
$_['text_success']     = 'Genial: Ha modificado el m&oacute;dulo de informaci&oacute;n!';
$_['text_edit']        = 'Editar M&oacute;dulo';

// Entry
$_['entry_status']     = 'Estado';

// Error
$_['error_permission'] = 'Atenci&oacute;n: No tiene permisos para modificar el m&oacute;dulo de informaci&oacute;n!';