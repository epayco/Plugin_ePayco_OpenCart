<?php
// Heading
$_['heading_title']    = 'PayPal Express Checkout';

// Text
$_['text_module'] = 'M&oacute;dulos';
$_['text_success'] = 'Genial: Ha modificado m&oacute;dulo del bot&oacute;n Pago expr&eacute;s';
$_['text_edit'] = 'M&oacute;dulo Editar bot&oacute;n Pago expr&eacute;s de PayPal';

// Entrada
$_['entry_status'] = 'Estado';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar el m&oacute;dulo del bot&oacute;n Pago expr&eacute;s de PayPal';