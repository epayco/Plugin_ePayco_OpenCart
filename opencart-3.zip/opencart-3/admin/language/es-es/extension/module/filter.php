<?php
// Heading
$_['heading_title']    = 'Filtro';

// Text
$_['text_module']      = 'M&oacute;dulo';
$_['text_success']     = 'Genial: Ha modificado los filtros!';
$_['text_edit']        = 'Editar m&oacute;dulo de Filtros';

// Entry
$_['entry_status']     = 'Estado';

// Error
$_['error_permission'] = 'Atenci&oacute;n: No tiene permisos para modificar los filtros!';