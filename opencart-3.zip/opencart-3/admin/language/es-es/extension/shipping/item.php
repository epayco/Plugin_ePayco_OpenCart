<?php
// Heading
$_['heading_title']     = 'Por Art&iacute;culo';

// Text
$_['text_shipping'] = 'Env&iacute;o';
$_['text_success'] = 'Genial: Se ha modificado el env&iacute;o por tasas art&iacute;culo!';
$_['text_edit'] = 'Editar Por art&iacute;culo del env&iacute;o';

// Entrada
$_['entry_cost'] = 'Coste';
$_['entry_tax_class'] = 'Clase de Impuesto';
$_['entry_geo_zone'] = 'Zona Geo';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Orden';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar el env&iacute;o por tasas art&iacute;culo!';