<?php
// Heading
$_['heading_title']    = 'Feeds';

// Text
$_['text_success']     = 'Genial: Usted ha modificado los feeds!';
$_['text_list']        = 'Feeds';

// Column
$_['column_name']      = 'Nombre del Feed de Producto';
$_['column_status']    = 'Estado';
$_['column_action']    = 'Acci&oacute;n';

// Error
$_['error_permission'] = 'Atenci&oacute;n: Usted no tiene permisos para modificar los feeds!';