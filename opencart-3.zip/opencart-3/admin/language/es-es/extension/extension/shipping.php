<?php
// Heading
$_['heading_title']     = 'Formas de Env&iacute;o';

// Text
$_['text_success']      = 'Genial: Usted ha modificado la forma de env&iacute;o!';
$_['text_list']         = 'Lista de Formas de Env&iacute;o';

// Column
$_['column_name']       = 'Metodo de Env&iacute;o';
$_['column_status']     = 'Estado';
$_['column_sort_order'] = 'Ordenar';
$_['column_action']     = 'Acci&oacute;n';

// Error
$_['error_permission']  = 'Atenci&oacute;n: Usted no tiene permisos para modificar el m&eacute;todo de env&iacute;o!';