<?php
// Heading
$_['heading_title']     = 'Tipos de Pagos';

// Text
$_['text_success']      = 'Genial: Usted ha modificado los tipos de pagos!';
$_['text_list']         = 'Lista de tipos de pago';

// Column
$_['column_name']       = 'Metodo de Pago';
$_['column_status']     = 'Estado';
$_['column_sort_order'] = 'Ordenar';
$_['column_action']     = 'Acci&oacute;n';

// Error
$_['error_permission']  = 'Atenci&oacute;n: Usted no tiene permisos para modificar los tipos de pago!';