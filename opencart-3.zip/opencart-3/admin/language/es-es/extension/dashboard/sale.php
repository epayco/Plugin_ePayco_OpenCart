<?php
// Heading
$_['heading_title'] = 'Total de Ventas';

// Text
$_['text_view']     = 'Ver m&aacute;s...';