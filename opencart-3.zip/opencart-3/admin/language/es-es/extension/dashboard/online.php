<?php
// Heading
$_['heading_title'] = 'Gente Online';

// Text
$_['text_view']     = 'Ver m&aacute;s...';