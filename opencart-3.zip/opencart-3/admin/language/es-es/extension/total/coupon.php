<?php
// Heading
$_['heading_title']    = 'Cup&oacute;n';

// Text
$_['text_total'] = 'Pedidos Totales';
$_['text_success'] = 'Genial: Ha modificado total de cup&oacute;n';
$_['text_edit'] = 'Editar Cup&oacute;n';

// Entrada
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Pedido';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar el total de los cupones';