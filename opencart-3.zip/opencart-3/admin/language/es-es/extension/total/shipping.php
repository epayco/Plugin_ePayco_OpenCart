<?php
// Heading
$_['heading_title']    = 'Env&iacute;o';

// Text
$_['text_total'] = 'Pedidos Totales';
$_['text_success'] = 'Genial: Ha modificado total del env&iacute;o';
$_['text_edit'] = 'Editar env&iacute;o Total';

// Entrada
$_['entry_estimator'] = 'Env&iacute;o Estimador';
$_['entry_status'] = 'Estado';
$_['entry_sort_order'] = 'Pedidos';

// Error
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para modificar total del env&iacute;o';