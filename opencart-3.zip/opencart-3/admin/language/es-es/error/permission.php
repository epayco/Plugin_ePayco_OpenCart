<?php
// Heading
$_['heading_title']   = 'Permiso Denegado!';

// Text
$_['text_permission'] = 'Usted no tiene permiso para acceder a esta p&aacute;gina, por favor, consulte al administrador del sistema.';