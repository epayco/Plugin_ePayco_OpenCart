<?php
// Heading
$_['heading_title']	   = 'Registro de Errores';

// Text
$_['text_success'] = 'Genial: Usted ha borrado con &eacute;xito su registro de errores';
$_['text_list'] = 'Lista de Errores';

// Error
$_['error_warning'] = 'Advertencia: El archivo de registro de errores% s es% s';
$_['error_permission'] = 'Advertencia: Usted no tiene permiso para borrar registro de errores ';