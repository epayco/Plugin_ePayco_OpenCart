<?php
$_['text_title'] = 'Credit Card / Debit Card or Cash with (ePayco)';