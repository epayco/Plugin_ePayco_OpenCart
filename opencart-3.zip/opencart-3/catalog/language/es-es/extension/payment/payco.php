<?php
// Text
$_['text_title'] = 'Paga con tu Tarjeta de Crédito / Débito o Efectivo con (ePayco)';