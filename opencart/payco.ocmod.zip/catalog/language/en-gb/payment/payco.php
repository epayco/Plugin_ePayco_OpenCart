<?php
$_['text_title']							= 'ePayco';
$_['text_payco_express']					= 'epayco';
$_['text_payco_card']						= 'epayco Card';
$_['text_wait']								= 'Please wait!';
$_['text_order_message']					= 'epayco Seller Protection - %s';
$_['xpay_discription_one'] = 'This site uses Payco because it is fraud-proof and private! Download the app to ypur phone and create an account. It takes less than 3 minutes.';
$_['xpay_discription_two'] = 'Just search for <b>Payco</b> where you get your apps!';
$_['xpay_discription_three'] = 'Then choose how you want to pay...';
$_['xpay_card_message'] = 'Though not recommended, you can also enter your card information like on other sites.';
$_['xpay_card_message'] = 'Though not recommended, you can also enter your card information like on other sites.';
$_['xpay_card_button_text'] = 'Just let me enter my card info.';
$_['xpay_card_number'] = 'Card Number';
$_['xpay_card_expiry_date'] = 'Expiry Date';
$_['xpay_card_code'] = 'Card Code (CVC)';
$_['xpay_card_zip'] = 'Card Zip';
$_['success_message'] = 'You just received a Purchase Offer in your XPay app. Complete your purchase by accepting offer and choosing your payment method.';
$_['button_confirm'] = 'Confirm Order';
$_['scan_code'] = '<div style="margin-top:20px"><p class="d-flex justify-content-center">Scan using</p> <p class="d-flex justify-content-center">your</p> <p class="d-flex justify-content-center">Payco</p> <p class="d-flex justify-content-center">App</p></div>';
$_['enter_phone'] = '<div><p class="d-flex justify-content-center">Enter your phone</p> <p class="d-flex justify-content-center">including area code</p></div>';
$_['enter_phone_two'] = '<div><p class="d-flex justify-content-center">Then open "offers"</p> <p class="d-flex justify-content-center">in your Payco App</p></div>';
$_['pay'] = 'PAY';
$_['time_out'] = 'QR Code time is over please try again!';
$_['retry'] = 'Retry';
$_['phone_number'] = 'please Enter Your Phone Number';
$_['status_codes'] = array(
                            '1' => "Purchasecode active",
                            '2' => "You declined this purchase offer.",
                            '3' => "Purchasecode scanned/received by customer",
                            '4' => "Sale successful",
                            '5' => "You declined this purchase offer.",
                            '7' => "You declined this purchase offer.",
                            '8' => "Busy or fail status returned from XBanc/acquirer",
                            '9' => "You declined this purchase offer."
                        );



?>